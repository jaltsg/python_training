.. toctree::

=============
API Reference
=============

.. contents:: Table of Contents
   :local:


GraphViz Module
+++++++++++++++

.. automodule:: pydotplus.graphviz
   :members:
   :undoc-members:


Parser Module
+++++++++++++

.. automodule:: pydotplus.parser
   :members:
   :undoc-members: